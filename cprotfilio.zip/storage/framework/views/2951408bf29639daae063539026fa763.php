<?php $__env->startSection('content'); ?>
    <div class="container" style="width: 90%">
        <div class="row">
            <div class="col-md-3">
                <?php
                    $sl = 1;
                ?>

                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($sl % 3 === 2): ?>
                        <div class="post-style1">
                            <div class="post-wrapper wow fadeIn" data-wow-duration="1s">
                                <!-- post image -->
                                <a href="<?php echo e(route('postDetails', $post->id)); ?>"><img src="<?php echo e(asset($post->image)); ?>"
                                        width="100%" class="img-responsive" alt=""></a>
                            </div>
                            <!-- post title -->
                            <h4><a href="<?php echo e(route('postDetails', $post->id)); ?>"><?php echo e($post->title); ?></a></h4>
                            <div class="post-title-author-details">
                                <div class="date">
                                    <ul>
                                        <li>By<a title=""
                                                href="#"><span><?php echo e($post->userCreator->name); ?></span></a>
                                            --</li>
                                        <li><a title="" href="#"><?php echo e($post->created_at->format('M j, Y')); ?></a>
                                            --</li>
                                        <li><a title="" href="#"><span>275 Comments</span></a></li>
                                    </ul>
                                </div>
                                <?php echo e(strlen(strip_tags($post->description)) > 50 ? substr(strip_tags($post->description), 0, 50) . '...' : strip_tags($post->description)); ?>

                                <?php if(strlen(strip_tags($post->description)) > 50): ?>
                                    <a href="<?php echo e(route('postDetails', $post->id)); ?>">Read More</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php
                        $sl++;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
            <div class="col-md-3">
                <?php
                    $sl = 1;
                ?>

                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($sl % 3 === 1): ?>
                        <div class="post-style1">
                            <div class="post-wrapper wow fadeIn" data-wow-duration="1s">
                                <!-- post image -->
                                <a href="<?php echo e(route('postDetails', $post->id)); ?>"><img src="<?php echo e(asset($post->image)); ?>"
                                        width="100% class="img-responsive" alt=""></a>
                            </div>
                            <!-- post title -->
                            <h4><a href="<?php echo e(route('postDetails', $post->id)); ?>"><?php echo e($post->title); ?></a></h4>
                            <div class="post-title-author-details">
                                <div class="date">
                                    <ul>
                                        <li>By<a title=""
                                                href="#"><span><?php echo e($post->userCreator->name); ?></span></a> --</li>
                                        <li><a title="" href="#"><?php echo e($post->created_at->format('M j, Y')); ?></a>
                                            --</li>
                                        <li><a title="" href="#"><span>275 Comments</span></a></li>
                                    </ul>
                                </div>
                                <?php echo e(strlen(strip_tags($post->description)) > 50 ? substr(strip_tags($post->description), 0, 50) . '...' : strip_tags($post->description)); ?>

                                <?php if(strlen(strip_tags($post->description)) > 50): ?>
                                    <a href="<?php echo e(route('postDetails', $post->id)); ?>">Read More</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php
                        $sl++;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <div class="col-md-3">
                <?php
                    $sl = 1;
                ?>

                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($sl % 3 === 0): ?>
                        <div class="post-style1">
                            <div class="post-wrapper wow fadeIn" data-wow-duration="1s">
                                <!-- post image -->
                                <a href="<?php echo e(route('postDetails', $post->id)); ?>"><img src="<?php echo e(asset($post->image)); ?>"
                                        width="100% class="img-responsive" alt=""></a>
                            </div>
                            <!-- post title -->
                            <h4><a href="<?php echo e(route('postDetails', $post->id)); ?>"><?php echo e($post->title); ?></a></h4>
                            <div class="post-title-author-details">
                                <div class="date">
                                    <ul>
                                        <li>By<a title=""
                                                href="#"><span><?php echo e($post->userCreator->name); ?></span></a> --</li>
                                        <li><a title="" href="#"><?php echo e($post->created_at->format('M j, Y')); ?></a>
                                            --</li>
                                        <li><a title="" href="#"><span>275 Comments</span></a></li>
                                    </ul>
                                </div>
                                <?php echo e(strlen(strip_tags($post->description)) > 50 ? substr(strip_tags($post->description), 0, 50) . '...' : strip_tags($post->description)); ?>

                                <?php if(strlen(strip_tags($post->description)) > 50): ?>
                                    <a href="<?php echo e(route('postDetails', $post->id)); ?>">Read More</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php
                        $sl++;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <aside class="col-md-3 left-padding">
                <div class="input-group search-area c-search">
                    <!-- search area -->
                    
                </div>
                <!-- social icon -->
                <h3 class="category-headding ">SOCIAL PIXEL</h3>
                <div class="headding-border"></div>
                <div class="social">
                    <ul>
                        <li><a href="<?php echo e($webSettings->social_link_2); ?>" class="facebook"><i
                                    class="fa  fa-facebook"></i>
                            </a>
                        </li>
                        <li><a href="<?php echo e($webSettings->social_link_1); ?>" class="twitter"><i
                                    class="fa  fa-twitter"></i></a>
                        </li>
                        <li><a href="<?php echo e($webSettings->social_link_3); ?>" class="google"><i
                                    class="fa  fa-google-plus"></i></a>
                        </li>
                        
                        </li>
                        <li><a href="<?php echo e($webSettings->social_link_5); ?>" style="background-color: rgb(199, 74, 74)"><i
                                    class="fa fa-pinterest"></i> </a>
                        </li>
                    </ul>
                </div>
                <!-- /.social icon -->
                <div class="tab-inner">
                    <ul class="tabs">
                        <li>Recent News</li>
                    </ul>
                    <hr>
                    <!-- tabs -->
                    <div class="tab_content">
                        <div class="tab-item-inner">
                            <?php $__currentLoopData = $recent_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent_new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="box-item wow fadeIn" data-wow-duration="1s">
                                    <div class="img-thumb">
                                        <a href="<?php echo e(route('postDetails', $recent_new->id)); ?>" rel="bookmark"><img
                                                class="entry-thumb" src="<?php echo e(asset($recent_new->image)); ?>" alt=""
                                                height="80" width="90"></a>
                                    </div>
                                    <div class="item-details">
                                        <h3 class="td-module-title"><a
                                                href="<?php echo e(route('postDetails', $recent_new->id)); ?>"><?php echo e($recent_new->title); ?></a>
                                        </h3>
                                        <div class="post-editor-date">
                                            <!-- post date -->
                                            <div class="post-date">
                                                <i class="pe-7s-clock"></i>
                                                <?php echo e($recent_new->created_at->format('M j, Y')); ?>

                                            </div>
                                            <!-- post comment -->
                                            <div class="post-author-comment"><i class="pe-7s-comment"></i> 13 </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!-- / tab item -->
                    </div>
                    <!-- / tab_content -->
                </div>
                <!-- / tab -->
                <div class="banner-add">
                    <!-- add -->
                    <span class="add-title">- Advertisement -</span>
                    <a href="#"><img src="<?php echo e(asset('frontend/images/ad-banner.jpg')); ?>"
                            class="img-responsive center-block" alt=""></a>
                </div>
                <!-- slider widget -->
                <div class="widget-slider-inner">
                    <h3 class="category-headding ">Slider Widget</h3>
                    <div class="headding-border"></div>
                    <div id="widget-slider" class="owl-carousel owl-theme">
                        <!-- widget item -->
                        <div class="item">
                            <a href="#"><img src="<?php echo e(asset('frontend/images/slider-widget-1.jpg')); ?>"
                                    alt=""></a>
                            <h4><a href="#">For good results must be make good plan</a></h4>
                            <div class="date">
                                <ul>
                                    <li>By<a title="" href="#"><span>Jone Kilna</span></a> --</li>
                                    <li><a title="" href="#">11 Nov 2015</a></li>
                                </ul>
                            </div>
                            <p>Dhaka: Dhaka Metropolitan Sessions a Judge Court on Wednesday issued warrants for the arrest
                                of 29 BNP leaders, including some ina senior leaders...</p>
                        </div>
                        <!-- widget item -->
                        <div class="item">
                            <a href="#"><img src="<?php echo e(asset('frontend/images/slider-widget-2.jpg')); ?>"
                                    alt=""></a>
                            <h4><a href="#">Dog invason sparks chaos at IPL match</a></h4>
                            <div class="date">
                                <ul>
                                    <li>By<a title="" href="#"><span>Jone Kilna</span></a> --</li>
                                    <li><a title="" href="#">11 Nov 2015</a></li>
                                </ul>
                            </div>
                            <p>Dhaka: Dhaka Metropolitan Sessions a Judge Court on Wednesday issued warrants for the arrest
                                of 29 BNP leaders, including some ina senior leaders ...</p>
                        </div>
                        <!-- widget item -->
                        <div class="item">
                            <a href="#"><img src="<?php echo e(asset('frontend/images/slider-widget-3.jpg')); ?>"
                                    alt=""></a>
                            <h4><a href="#">For good results must be make good plan</a></h4>
                            <div class="date">
                                <ul>
                                    <li>By<a title="" href="#"><span>Jone Kilna</span></a> --</li>
                                    <li><a title="" href="#">11 Nov 2015</a></li>
                                </ul>
                            </div>
                            <p>Dhaka: Dhaka Metropolitan Sessions a Judge Court on Wednesday issued warrants for the arrest
                                of 29 BNP leaders, including some ina senior leaders ...</p>
                        </div>
                    </div>
                </div>
            </aside>
        </div>
        <!-- pagination -->
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <ul class="pagination">
                        
                        <?php if($posts->onFirstPage()): ?>
                            <li class="disabled"><span>&laquo;</span></li>
                        <?php else: ?>
                            <li><a href="<?php echo e($posts->previousPageUrl()); ?>" rel="prev">&laquo;</a></li>
                        <?php endif; ?>

                        
                        <?php for($i = 1; $i <= $posts->lastPage(); $i++): ?>
                            <?php if($i == $posts->currentPage()): ?>
                                <li class="active"><span><?php echo e($i); ?></span></li>
                            <?php else: ?>
                                <li><a href="<?php echo e($posts->url($i)); ?>"><?php echo e($i); ?></a></li>
                            <?php endif; ?>
                        <?php endfor; ?>

                        
                        <?php if($posts->hasMorePages()): ?>
                            <li><a href="<?php echo e($posts->nextPageUrl()); ?>" rel="next">&raquo;</a></li>
                        <?php else: ?>
                            <li class="disabled"><span>&raquo;</span></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cprotfolio\resources\views/frontend/home/subCategoryPages.blade.php ENDPATH**/ ?>