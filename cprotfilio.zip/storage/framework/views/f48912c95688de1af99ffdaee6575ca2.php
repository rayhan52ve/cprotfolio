 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
 <script type="text/javascript" src="<?php echo e(asset('frontend')); ?>/js/jquery.min.js"></script>
 <!-- Include all compiled plugins (below), or include individual files as needed -->
 <script type="text/javascript" src="<?php echo e(asset('frontend')); ?>/js/bootstrap.min.js"></script>
 <!-- Metis Menu Plugin JavaScript -->
 <script type="text/javascript" src="<?php echo e(asset('frontend')); ?>/js/metisMenu.min.js"></script>
 <!-- Scrollbar js -->
 <script type="text/javascript" src="<?php echo e(asset('frontend')); ?>/js/jquery.mCustomScrollbar.concat.min.js"></script>
 <!-- animate js -->
 <script type="text/javascript" src="<?php echo e(asset('frontend')); ?>/js/wow.min.js"></script>
 <!-- Newstricker js -->
 <script type="text/javascript" src="<?php echo e(asset('frontend')); ?>/js/jquery.newsTicker.js"></script>
 <!--  classify JavaScript -->
 <script type="text/javascript" src="<?php echo e(asset('frontend')); ?>/js/classie.js"></script>
 <!-- owl carousel js -->
 <script type="text/javascript" src="<?php echo e(asset('frontend')); ?>/owl-carousel/owl.carousel.js"></script>
 <!-- youtube js -->
 <script type="text/javascript" src="<?php echo e(asset('frontend')); ?>/js/RYPP.js"></script>
 <!-- jquery ui js -->
 <script type="text/javascript" src="<?php echo e(asset('frontend')); ?>/js/jquery-ui.js"></script>
 <!-- form -->
 <script type="text/javascript" src="<?php echo e(asset('frontend')); ?>/js/form-classie.js"></script>
 <!-- custom js -->
 <script type="text/javascript" src="<?php echo e(asset('frontend')); ?>/js/custom.js"></script>
 
 <script src="https://bangla.plus/scripts/bangladatetoday.min.js"></script>
 <script>
     dateToday('date-today', 'bangla');
 </script>
<?php /**PATH C:\laragon\www\cprotfolio\resources\views/frontend/inc/script.blade.php ENDPATH**/ ?>