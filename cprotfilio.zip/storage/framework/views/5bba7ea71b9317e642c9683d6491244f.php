<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <marquee>
            <?php echo $webSettings->breaking_news; ?>

        </marquee>
    </div>

    <div class="container-fluid" style="margin-top: 40px;">
        <div class="row">
            <div class="col-md-8 col-sm-8">
                <!-- left content inner -->
                <section class="recent_news_inner">
                    <h3 class="category-headding ">RECENT NEWS</h3>
                    <div class="headding-border"></div>
                    <div class="row">
                        <div id="content-slide" class="owl-carousel">
                            <?php $__currentLoopData = $recent_news->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent_new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item home2-post">
                                    <div class="post-wrapper wow fadeIn" data-wow-duration="1s">
                                        <!-- image -->
                                        <div class="post-thumb">
                                            <a href="<?php echo e(route('postDetails', $recent_new->id)); ?>">
                                                <img class="img-responsive" src="<?php echo e(asset($recent_new->image)); ?>"
                                                    alt="">
                                            </a>
                                        </div>
                                        <div class="post-info meta-info-rn">
                                            
                                        </div>
                                    </div>
                                    <h3><a href="<?php echo e(route('postDetails', $recent_new->id)); ?>"><?php echo e($recent_new->title); ?></a>
                                    </h3>
                                    <div class="post-title-author-details">
                                        <div class="date">
                                            <ul>
                                                <li>By <a title=""
                                                        href="#"><span><?php echo e($recent_new->userCreator->name); ?></span></a>
                                                    --
                                                </li>
                                                <li><a title=""
                                                        href="#"><?php echo e($recent_new->created_at->format('M j, Y')); ?></a>
                                                    --</li>
                                                <li><a title=""
                                                        href="#"><span><?php echo e($recent_new->category->name ?? null); ?></span></a>
                                                </li>
                                            </ul>
                                        </div>
                                        <p>
                                            <?php echo e(strlen(strip_tags($recent_new->description)) > 50 ? substr(strip_tags($recent_new->description), 0, 50) . '...' : strip_tags($recent_new->description)); ?>

                                            <?php if(strlen(strip_tags($recent_new->description)) > 50): ?>
                                                <a href="<?php echo e(route('postDetails', $recent_new->id)); ?>">Read More</a>
                                            <?php endif; ?>

                                        </p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                    <div class="row rn_block">
                        <?php $__currentLoopData = $recent_news->skip(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent_new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 col-sm-4 padd">
                                <div class="home2-post">
                                    <div class="post-wrapper wow fadeIn" data-wow-duration="1s">
                                        <!-- image -->
                                        <div class="post-thumb">
                                            <a href="<?php echo e(route('postDetails', $recent_new->id)); ?>">
                                                <img class="img-responsive" src="<?php echo e(asset($recent_new->image)); ?>"
                                                    alt="">
                                            </a>
                                        </div>
                                        <div class="post-info meta-info-rn">
                                            
                                        </div>
                                    </div>
                                    <div class="post-title-author-details">
                                        <h4><a
                                                href="<?php echo e(route('postDetails', $recent_new->id)); ?>"><?php echo e($recent_new->title); ?></a>
                                        </h4>
                                        <div class="date">
                                            <ul>
                                                <li>By <a title=""
                                                        href="#"><span><?php echo e($recent_new->userCreator->name); ?></span></a>
                                                    --
                                                </li>
                                                <li><a title=""
                                                        href="#"><?php echo e($recent_new->created_at->format('M j, Y')); ?></a>
                                                </li>
                                                <li><a title=""
                                                        href="#"><span><?php echo e($recent_new->category->name ?? null); ?></span></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </section>
                <!-- Politics Area
                                                                                                                                                        ============================================ -->
                <section class="politics_wrapper">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h3 class="category-headding"><?php echo e($category->name); ?></h3>
                        <div class="headding-border"></div>
                        <div class="row">
                            <!-- item -->
                            <div class="item">
                                <div class="row">
                                    <!-- main post -->
                                    <div class="col-sm-6 col-md-6">
                                        <?php $__currentLoopData = $category->posts->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="home2-post">
                                                <div class="post-wrapper wow fadeIn" data-wow-duration="1s">
                                                    <!-- post image -->
                                                    <div class="post-thumb">
                                                        <a href="<?php echo e(route('postDetails', $post->id)); ?>">
                                                            <img src="<?php echo e(asset($post->image)); ?>" class="img-responsive"
                                                                alt="">
                                                        </a>
                                                    </div>
                                                    <!-- post title -->
                                                    <h3><a
                                                            href="<?php echo e(route('postDetails', $post->id)); ?>"><?php echo e($post->title); ?></a>
                                                    </h3>
                                                </div>
                                                <div class="post-title-author-details">
                                                    <div class="date">
                                                        <ul>
                                                            <li>By <a
                                                                    href="#"><span><?php echo e($post->userCreator->name); ?></span></a>
                                                                --</li>
                                                            <li><a
                                                                    href="#"><?php echo e($post->created_at->format('M j, Y')); ?></a>
                                                                --</li>
                                                            <li><a
                                                                    href="#"><span><?php echo e($post->category->name ?? null); ?></span></a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <p><?php echo e(strlen(strip_tags($post->description)) > 50 ? substr(strip_tags($post->description), 0, 150) . '...' : strip_tags($post->description)); ?>

                                                        <?php if(strlen(strip_tags($post->description)) > 50): ?>
                                                            <a href="<?php echo e(route('postDetails', $post->id)); ?>">Read
                                                                More</a>
                                                        <?php endif; ?>
                                                    </p>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <!-- right side post -->
                                    <div class="col-sm-6 col-md-6">
                                        <div class="row rn_block">
                                            <?php $__currentLoopData = $category->posts->skip(1)->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-xs-6 col-md-6 col-sm-6 post-padding">
                                                    <div class="home2-post">
                                                        <!-- post image -->
                                                        <div class="post-thumb wow fadeIn" data-wow-duration="1s"
                                                            data-wow-delay="0.2s">
                                                            <a href="<?php echo e(route('postDetails', $post->id)); ?>">
                                                                <img src="<?php echo e(asset($post->image)); ?>" class="img-responsive"
                                                                    alt="">
                                                            </a>
                                                        </div>
                                                        <div class="post-title-author-details">
                                                            <!-- post image -->
                                                            <h5><a
                                                                    href="<?php echo e(route('postDetails', $post->id)); ?>"><?php echo e($post->title); ?></a>
                                                            </h5>
                                                            <div class="date">
                                                                <ul>
                                                                    <li><a
                                                                            href="#"><span><?php echo e($post->userCreator->name); ?></span></a>
                                                                        --</li>
                                                                    <li><a
                                                                            href="#"><?php echo e($post->created_at->format('M j, Y')); ?></a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- item -->
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- /.row -->
                </section>
                <!-- /.Politics -->
                
                <div class="banner">
                    <a href="<?php echo e($banner->home_banner_link2); ?>">
                        <img src="<?php echo e(asset($banner->homebanner2)); ?>" width="800px" style="max-height:150px"
                            class="img-responsive center-block" alt=""></a>
                </div>


            </div>
            <!-- /.left content inner -->
            <div class="col-md-4 col-sm-4 left-padding">
                <!-- right content wrapper -->
                <div class="input-group search-area">
                    <!-- search area -->
                    <input type="text" class="form-control" placeholder="Search articles here ..." name="q">
                    <div class="input-group-btn">
                        <button class="btn btn-search" type="submit"><i class="fa fa-search"
                                aria-hidden="true"></i></button>
                    </div>
                </div>
                <!-- /.search area -->
                <!-- social icon -->
                <h3 class="category-headding ">SOCIAL PIXEL</h3>
                <div class="headding-border"></div>
                <div class="social">
                    <ul>
                        <li><a href="<?php echo e($webSettings->social_link_2); ?>" class="facebook"><i
                                    class="fa  fa-facebook"></i><span>3987</span>
                            </a>
                        </li>
                        <li><a href="<?php echo e($webSettings->social_link_1); ?>" class="twitter"><i
                                    class="fa  fa-twitter"></i><span>3987</span></a>
                        </li>
                        <li><a href="<?php echo e($webSettings->social_link_3); ?>" class="google"><i
                                    class="fa  fa-google-plus"></i><span>3987</span></a>
                        </li>
                        <li><a href="<?php echo e($webSettings->social_link_4); ?>" style="background-color: skyblue"><i
                                    class="fa fa-vimeo"></i><span>3987</span> </a>
                        </li>
                        <li><a href="<?php echo e($webSettings->social_link_5); ?>" style="background-color: rgb(199, 74, 74)"><i
                                    class="fa fa-pinterest"></i><span>3987</span> </a>
                        </li>
                    </ul>
                </div>
                <!-- /.social icon -->
                <div class="banner-add">
                    <!-- add -->
                    
                    <a href="<?php echo e(@$banner->banner_link4); ?>"><img src="<?php echo e(asset($banner->banner4)); ?>"
                            class="img-responsive center-block" width="300px" style="height: 300px" alt=""></a>
                </div>
                <div class="tab-inner">
                    <ul class="tabs">
                        <li>Recent News</li>
                    </ul>
                    <hr>
                    <!-- tabs -->
                    <div class="tab_content">
                        <div class="tab-item-inner">
                            <?php $__currentLoopData = $recent_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent_new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="box-item wow fadeIn" data-wow-duration="1s">
                                    <div class="img-thumb">
                                        <a href="<?php echo e(route('postDetails', $recent_new->id)); ?>" rel="bookmark"><img
                                                class="entry-thumb" src="<?php echo e(asset($recent_new->image)); ?>" alt=""
                                                height="80" width="90"></a>
                                    </div>
                                    <div class="item-details">
                                        <h3 class="td-module-title"><a
                                                href="<?php echo e(route('postDetails', $recent_new->id)); ?>"><?php echo e($recent_new->title); ?></a>
                                        </h3>
                                        <div class="post-editor-date">
                                            <!-- post date -->
                                            <div class="post-date">
                                                <i class="pe-7s-clock"></i>
                                                <?php echo e($recent_new->created_at->format('M j, Y')); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!-- / tab_content -->
                    </div>
                    <!-- / tab -->
                </div>
                <!-- side content end -->
            </div>
            <!-- row end -->
        </div>
        <!-- container-fluid end -->

        <!-- second content -->
        <section>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="row">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-sm-4 col-md-4">
                                    <div class="buisness">
                                        <h3 class="category-headding "><?php echo e($category->name); ?></h3>
                                        <div class="headding-border bg-color-5"></div>
                                        <?php $__currentLoopData = $category->posts->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="post-wrapper wow fadeIn" data-wow-duration="1s">
                                                <!-- post title -->
                                                <h3><a href="#"><?php echo e($post->title); ?></a></h3>
                                                <!-- post image -->
                                                <div class="post-thumb">
                                                    <a href="<?php echo e(route('postDetails', $post->id)); ?>">
                                                        <img src="<?php echo e(asset($post->image)); ?>" class="img-responsive"
                                                            alt="">
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="post-title-author-details">
                                                <div class="post-editor-date">
                                                    <!-- post date -->
                                                    <div class="post-date">
                                                        <i class="pe-7s-clock"></i>
                                                        <?php echo e($post->created_at->format('M j, Y')); ?>

                                                    </div>
                                                    <!-- post comment -->
                                                    
                                                </div>
                                                <p><?php echo e(strlen(strip_tags($post->description)) > 50 ? substr(strip_tags($post->description), 0, 150) . '...' : strip_tags($post->description)); ?>

                                                    <?php if(strlen(strip_tags($post->description)) > 50): ?>
                                                        <a href="<?php echo e(route('postDetails', $post->id)); ?>">Read More</a>
                                                    <?php endif; ?>
                                                </p>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $category->posts->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="box-item wow fadeIn" data-wow-duration="1s"
                                                data-wow-delay="0.2s">
                                                <div class="img-thumb">
                                                    <a href="<?php echo e(route('postDetails', $post->id)); ?>" rel="bookmark"><img
                                                            class="entry-thumb" src="<?php echo e(asset($post->image)); ?>"
                                                            alt="" height="70" width="100"></a>
                                                </div>
                                                <div class="item-details">
                                                    <h3 class="td-module-title"><a href="#"><?php echo e($post->title); ?></a>
                                                    </h3>
                                                    <div class="post-editor-date">
                                                        <!-- post date -->
                                                        <div class="post-date">
                                                            <i class="pe-7s-clock"></i>
                                                            <?php echo e($post->created_at->format('M j, Y')); ?>

                                                        </div>
                                                        <!-- post comment -->
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>


                    </div>
                </div>
            </div>
        </section>
        <!-- second content end -->
        <!-- Video News Area
                                                                                                                                            ============================================ -->
        <section class="video-post-inner">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-12">
                        <h3 class="category-headding ">VIDEO POST</h3>
                        <div class="headding-border"></div>
                    </div>
                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-4">
                            <div class="post-style1">
                                <div class="post-wrapper wow fadeIn" data-wow-duration="1s">
                                    <iframe width="100%" height="350"
                                    src="https://www.youtube.com/embed/<?php echo e($video->video); ?>">
                                    </iframe>
                                </div>
                                <!-- post title -->
                                <h3><a href="#"><?php echo e($video->title); ?></a></h3>
                                <div class="post-title-author-details">
                                    <div class="date">
                                        <ul>

                                            <li>By <span class="text-danger"><?php echo e($video->userCreator->name); ?></span>--</li>
                                            <li><?php echo e($video->created_at->format('M j, Y')); ?></li>
                                            
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
            </div>
        </section>
        <!-- Article Post
                                                                                                                                            ============================================ -->
        <section class="article-post-inner">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-8">
                        <div class="articale-list">
                            <h3 class="category-headding ">Latest News</h3>
                            <div class="headding-border"></div>
                            <!--Post list-->
                            <?php $__currentLoopData = $recent_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent_new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="post-style2 wow fadeIn" data-wow-duration="1s">
                                    <a href="<?php echo e(route('postDetails', $recent_new->id)); ?>"><img
                                            src="<?php echo e(asset($recent_new->image)); ?>" width="300px" alt=""></a>
                                    <div class="post-style2-detail">
                                        <h3><a href="#" title=""> <?php echo e($recent_new->title); ?></a></h3>
                                        <div class="date">
                                            <ul>
                                                <li>By <a title=""
                                                        href="#"><span><?php echo e($recent_new->userCreator->name); ?></span></a>
                                                    --</li>
                                                <li><a title=""
                                                        href="#"><?php echo e($recent_new->created_at->format('M j, Y')); ?></a>
                                                    --
                                                </li>
                                                <li><a title=""
                                                        href="#"><span><?php echo e($recent_new->category->name ?? null); ?></span></a>
                                                </li>
                                            </ul>
                                        </div>
                                        <p><?php echo e(strlen(strip_tags($recent_new->description)) > 50 ? substr(strip_tags($recent_new->description), 0, 50) . '...' : strip_tags($recent_new->description)); ?>

                                            <?php if(strlen(strip_tags($recent_new->description)) > 50): ?>
                                                <a href="<?php echo e(route('postDetails', $recent_new->id)); ?>">Read More</a>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                    <div class="col-sm-4 left-padding">
                        <!-- slider widget -->
                        <div class="widget-slider-inner">
                            <h3 class="category-headding ">Slider Widget</h3>
                            <div class="headding-border"></div>
                            <div id="widget-slider" class="owl-carousel owl-theme">
                                <!-- widget item -->
                                <div class="item">
                                    <a href="#"><img src="<?php echo e(asset('frontend')); ?>/images/slider-widget-1.jpg"
                                            alt=""></a>
                                    <h4><a href="#">For good results must be make good plan</a></h4>
                                    <div class="date">
                                        <ul>
                                            <li>By<a title="" href="#"><span>Jone Kilna</span></a> --</li>
                                            <li><a title="" href="#">Oct 6, 2016</a></li>
                                        </ul>
                                    </div>
                                    <p>Dhaka: Dhaka Metropolitan Sessions a Judge Court on Wednesday issued warrants for the
                                        arrest of 29 BNP leaders, including some ina senior leaders...</p>
                                </div>
                                <!-- widget item -->
                                <div class="item">
                                    <a href="#"><img src="<?php echo e(asset('frontend')); ?>/images/slider-widget-2.jpg"
                                            alt=""></a>
                                    <h4><a href="#">Dog invason sparks chaos at IPL match</a></h4>
                                    <div class="date">
                                        <ul>
                                            <li>By<a title="" href="#"><span>Jone Kilna</span></a> --</li>
                                            <li><a title="" href="#">Oct 6, 2016</a></li>
                                        </ul>
                                    </div>
                                    <p>Dhaka: Dhaka Metropolitan Sessions a Judge Court on Wednesday issued warrants for the
                                        arrest of 29 BNP leaders, including some ina senior leaders ...</p>
                                </div>
                                <!-- widget item -->
                                <div class="item">
                                    <a href="#"><img src="<?php echo e(asset('frontend')); ?>/images/slider-widget-3.jpg"
                                            alt=""></a>
                                    <h4><a href="#">For good results must be make good plan</a></h4>
                                    <div class="date">
                                        <ul>
                                            <li>By<a title="" href="#"><span>Jone Kilna</span></a> --</li>
                                            <li><a title="" href="#">Oct 6, 2016</a></li>
                                        </ul>
                                    </div>
                                    <p>Dhaka: Dhaka Metropolitan Sessions a Judge Court on Wednesday issued warrants for the
                                        arrest of 29 BNP leaders, including some ina senior leaders ...</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- pagination -->
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <div class="banner">
                        <a href="<?php echo e($banner->home_banner_link3); ?>"></a>
                        <img src="<?php echo e(asset($banner->homebanner3)); ?>" width="800px" style="max-height:150px"
                            class="img-responsive center-block" alt="">
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cprotfolio\resources\views/frontend/home/index.blade.php ENDPATH**/ ?>