<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('frontend.inc.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<body>
    <div class="se-pre-con"></div>
    <?php echo $__env->make('frontend.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- header news Area
        ============================================ -->
<?php echo $__env->yieldContent('content'); ?>
    <!-- footer Area
        ============================================ -->
<?php echo $__env->make('frontend.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /.sub footer -->
   <?php echo $__env->make('frontend.inc.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>


</html>
<?php /**PATH C:\laragon\www\cprotfolio\resources\views/frontend/layout.blade.php ENDPATH**/ ?>