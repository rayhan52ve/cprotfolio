<?php
$webSettings = App\Models\WebSettings::first();
